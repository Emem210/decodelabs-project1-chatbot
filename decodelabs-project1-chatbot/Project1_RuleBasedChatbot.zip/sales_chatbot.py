"""
DecodeLabs – Project 1: Rule-Based AI Chatbot
Powered by: Sales Intelligence Engine
Dataset: Product-Sales-Region (1,500 orders)
"""

import pandas as pd

# ─────────────────────────────────────────────
#  PHASE 1 – LOAD & PRECOMPUTE KNOWLEDGE BASE
# ─────────────────────────────────────────────
df = pd.read_excel("Product-Sales-Region.xlsx")

# Pre-aggregate stats so lookups are O(1)
REGION_SALES   = df.groupby("Region")["TotalPrice"].sum().round(2).to_dict()
PRODUCT_SALES  = df.groupby("Product")["TotalPrice"].sum().round(2).to_dict()
SALES_BY_REP   = df.groupby("Salesperson")["TotalPrice"].sum().round(2).to_dict()
PRODUCT_QTY    = df.groupby("Product")["Quantity"].sum().to_dict()
RETURN_RATE    = (df.groupby("Product")["Returned"].mean() * 100).round(1).to_dict()
REGION_ORDERS  = df["Region"].value_counts().to_dict()
PAYMENT_COUNTS = df["PaymentMethod"].value_counts().to_dict()
PROMO_COUNTS   = df["Promotion"].value_counts().to_dict()
TOTAL_REVENUE  = round(df["TotalPrice"].sum(), 2)
TOTAL_ORDERS   = len(df)

TOP_REGION     = max(REGION_SALES, key=REGION_SALES.get)
TOP_PRODUCT    = max(PRODUCT_SALES, key=PRODUCT_SALES.get)
TOP_REP        = max(SALES_BY_REP, key=SALES_BY_REP.get)
MOST_RETURNED  = max(RETURN_RATE, key=RETURN_RATE.get)
BEST_PROMO     = max(PROMO_COUNTS, key=PROMO_COUNTS.get)

REGIONS   = [r.lower() for r in REGION_SALES]
PRODUCTS  = [p.lower() for p in PRODUCT_SALES]
REPS      = [s.lower() for s in SALES_BY_REP]

# ─────────────────────────────────────────────
#  PHASE 1 – SANITIZATION
# ─────────────────────────────────────────────
def sanitize(raw: str) -> str:
    return raw.lower().strip()

# ─────────────────────────────────────────────
#  PHASE 2 – PROCESS (The Logic Skeleton)
# ─────────────────────────────────────────────
def get_response(user_input: str) -> str:

    # ── INTENT: EXIT ──────────────────────────
    exit_commands = {"exit", "quit", "bye", "goodbye", "q", "stop"}
    if user_input in exit_commands:
        return "__EXIT__"

    # ── INTENT: GREETING ──────────────────────
    greetings = {
        "hello": "Hello! 👋 I'm your Sales Intelligence Bot. Ask me about regions, products, salespersons, returns, or promotions. Type 'help' for a full list.",
        "hi":    "Hi there! I can answer questions about our 1,500-order sales dataset. Try: 'top region', 'best product', or 'help'.",
        "hey":   "Hey! Ready to crunch some sales data. What would you like to know?",
        "good morning": "Good morning! ☀️ Ready to explore the sales data?",
        "good evening": "Good evening! 🌙 Ask me anything about the sales dataset.",
    }
    if user_input in greetings:
        return greetings[user_input]

    # ── INTENT: HELP ──────────────────────────
    help_triggers = {"help", "menu", "options", "commands", "what can you do", "guide"}
    if user_input in help_triggers:
        return (
            "\n📋 WHAT I CAN ANSWER:\n"
            "  • total revenue / total sales\n"
            "  • top region / worst region\n"
            "  • sales by region  (e.g. 'east sales')\n"
            "  • top product / worst product\n"
            "  • sales by product (e.g. 'laptop sales')\n"
            "  • top salesperson / all reps\n"
            "  • sales by rep     (e.g. 'eva sales')\n"
            "  • returns          (e.g. 'return rate laptop')\n"
            "  • most returned product\n"
            "  • total orders\n"
            "  • payment methods\n"
            "  • best promotion\n"
            "  • exit / quit  → close the chatbot\n"
        )

    # ── INTENT: TOTAL REVENUE ─────────────────
    revenue_triggers = {"total revenue", "total sales", "revenue", "overall sales",
                         "how much total", "total income"}
    if user_input in revenue_triggers:
        return f"💰 Total revenue across all 1,500 orders: ${TOTAL_REVENUE:,.2f}"

    # ── INTENT: TOTAL ORDERS ──────────────────
    order_triggers = {"total orders", "how many orders", "order count", "orders"}
    if user_input in order_triggers:
        return f"📦 The dataset contains {TOTAL_ORDERS:,} total orders."

    # ── INTENT: TOP / WORST REGION ────────────
    top_region_triggers = {"top region", "best region", "highest region",
                            "which region", "region leader"}
    if user_input in top_region_triggers:
        return (f"🏆 Top Region: {TOP_REGION}  →  ${REGION_SALES[TOP_REGION]:,.2f} in sales\n"
                f"   (Type 'sales by region' for a full breakdown)")

    worst_region_triggers = {"worst region", "lowest region", "bottom region", "weakest region"}
    if user_input in worst_region_triggers:
        worst = min(REGION_SALES, key=REGION_SALES.get)
        return f"📉 Worst Region: {worst}  →  ${REGION_SALES[worst]:,.2f} in sales"

    if user_input in {"sales by region", "region breakdown", "all regions", "region sales"}:
        lines = ["📊 Sales by Region:"]
        for r, v in sorted(REGION_SALES.items(), key=lambda x: -x[1]):
            lines.append(f"   {r:<10} ${v:>12,.2f}")
        return "\n".join(lines)

    # ── INTENT: SPECIFIC REGION ───────────────
    for region in REGIONS:
        if region in user_input and ("sales" in user_input or "revenue" in user_input
                                       or "orders" in user_input or user_input == region):
            R = region.capitalize()
            return (f"📍 Region: {R}\n"
                    f"   Revenue : ${REGION_SALES[R]:,.2f}\n"
                    f"   Orders  : {REGION_ORDERS.get(R, 'N/A'):,}")

    # ── INTENT: TOP / WORST PRODUCT ───────────
    top_product_triggers = {"top product", "best product", "best selling", "best seller",
                              "highest product", "most sold"}
    if user_input in top_product_triggers:
        return (f"🏆 Top Product: {TOP_PRODUCT}  →  ${PRODUCT_SALES[TOP_PRODUCT]:,.2f} in sales\n"
                f"   (Type 'sales by product' for a full list)")

    worst_product_triggers = {"worst product", "lowest product", "bottom product", "least sold"}
    if user_input in worst_product_triggers:
        worst = min(PRODUCT_SALES, key=PRODUCT_SALES.get)
        return f"📉 Worst Product: {worst}  →  ${PRODUCT_SALES[worst]:,.2f} in sales"

    if user_input in {"sales by product", "product breakdown", "all products", "product sales"}:
        lines = ["📊 Sales by Product:"]
        for p, v in sorted(PRODUCT_SALES.items(), key=lambda x: -x[1]):
            lines.append(f"   {p:<10} ${v:>12,.2f}")
        return "\n".join(lines)

    # ── INTENT: SPECIFIC PRODUCT ──────────────
    for product in PRODUCTS:
        if product in user_input:
            P = product.capitalize()
            return (f"📦 Product: {P}\n"
                    f"   Revenue     : ${PRODUCT_SALES[P]:,.2f}\n"
                    f"   Units Sold  : {PRODUCT_QTY[P]:,}\n"
                    f"   Return Rate : {RETURN_RATE[P]}%")

    # ── INTENT: SALESPERSON ───────────────────
    top_rep_triggers = {"top salesperson", "best salesperson", "best rep", "top rep",
                         "highest sales rep", "salesperson", "who sold most"}
    if user_input in top_rep_triggers:
        return (f"🏆 Top Salesperson: {TOP_REP}  →  ${SALES_BY_REP[TOP_REP]:,.2f}\n"
                f"   (Type 'all reps' for the full leaderboard)")

    if user_input in {"all reps", "all salespeople", "rep leaderboard", "salespeople",
                       "sales reps", "rep breakdown"}:
        lines = ["👥 Salesperson Leaderboard:"]
        for rank, (rep, val) in enumerate(
                sorted(SALES_BY_REP.items(), key=lambda x: -x[1]), 1):
            lines.append(f"   #{rank}  {rep:<10} ${val:>12,.2f}")
        return "\n".join(lines)

    for rep in REPS:
        if rep in user_input and ("sales" in user_input or "revenue" in user_input
                                    or user_input == rep):
            R = rep.capitalize()
            return (f"🧑‍💼 Salesperson: {R}\n"
                    f"   Total Sales: ${SALES_BY_REP[R]:,.2f}")

    # ── INTENT: RETURNS ───────────────────────
    return_triggers = {"most returned", "highest return rate", "returned most",
                        "which product is returned most", "return leader"}
    if user_input in return_triggers:
        return (f"🔄 Most Returned Product: {MOST_RETURNED}  →  "
                f"{RETURN_RATE[MOST_RETURNED]}% return rate")

    if user_input in {"return rates", "all returns", "return breakdown", "returns"}:
        lines = ["🔄 Return Rates by Product:"]
        for p, v in sorted(RETURN_RATE.items(), key=lambda x: -x[1]):
            lines.append(f"   {p:<10} {v}%")
        return "\n".join(lines)

    if "return rate" in user_input:
        for product in PRODUCTS:
            if product in user_input:
                P = product.capitalize()
                return f"🔄 {P} Return Rate: {RETURN_RATE[P]}%"

    # ── INTENT: PAYMENT METHODS ───────────────
    payment_triggers = {"payment methods", "how do customers pay", "payment breakdown",
                         "payment", "payments"}
    if user_input in payment_triggers:
        lines = ["💳 Payment Method Usage:"]
        for method, count in sorted(PAYMENT_COUNTS.items(), key=lambda x: -x[1]):
            lines.append(f"   {method:<15} {count:,} orders")
        return "\n".join(lines)

    # ── INTENT: PROMOTIONS ────────────────────
    promo_triggers = {"promotions", "best promotion", "most used promo",
                       "promo breakdown", "discount codes", "promotion"}
    if user_input in promo_triggers:
        lines = [f"🎁 Best Promotion: {BEST_PROMO} ({PROMO_COUNTS[BEST_PROMO]:,} uses)\n",
                 "   Full Promo Usage:"]
        for promo, count in sorted(PROMO_COUNTS.items(), key=lambda x: -x[1]):
            lines.append(f"   {promo:<12} {count:,} orders")
        return "\n".join(lines)

    # ── INTENT: ABOUT / INFO ──────────────────
    about_triggers = {"about", "dataset", "data info", "what data", "data"}
    if user_input in about_triggers:
        return (f"ℹ️  Dataset: Product-Sales-Region\n"
                f"   Orders      : {TOTAL_ORDERS:,}\n"
                f"   Total Rev   : ${TOTAL_REVENUE:,.2f}\n"
                f"   Regions     : {', '.join(REGION_SALES.keys())}\n"
                f"   Products    : {', '.join(PRODUCT_SALES.keys())}\n"
                f"   Sales Reps  : {', '.join(SALES_BY_REP.keys())}")

    # ── FALLBACK ──────────────────────────────
    return ("❓ I didn't understand that. Try 'help' to see what I can answer.\n"
            "   Tip: You can ask things like 'east sales', 'laptop return rate', or 'top rep'.")

# ─────────────────────────────────────────────
#  PHASE 3 – OUTPUT (Continuous Feedback Loop)
# ─────────────────────────────────────────────
def run_chatbot():
    print("\n" + "="*55)
    print("  🤖  SALES INTELLIGENCE CHATBOT  |  DecodeLabs")
    print("="*55)
    print("  Dataset: Product-Sales-Region  |  1,500 orders")
    print("  Type 'help' for commands  |  'exit' to quit")
    print("="*55 + "\n")

    while True:
        try:
            raw_input_str = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print("\nBot: Session ended. Goodbye! 👋")
            break

        # SANITIZE
        clean = sanitize(raw_input_str)

        if not clean:
            print("Bot: Please enter a message.\n")
            continue

        # PROCESS
        response = get_response(clean)

        # EXIT CHECK
        if response == "__EXIT__":
            print("Bot: Goodbye! Thanks for exploring the sales data. 👋\n")
            break

        # OUTPUT
        print(f"Bot: {response}\n")

if __name__ == "__main__":
    run_chatbot()
